package com.example.booksapp

import androidx.lifecycle.ViewModel

class CreateUserViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
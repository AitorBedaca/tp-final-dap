package com.example.booksapp

import androidx.lifecycle.ViewModel

class DescriptionViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
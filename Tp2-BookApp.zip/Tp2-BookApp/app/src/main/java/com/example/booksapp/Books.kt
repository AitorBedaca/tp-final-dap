package com.example.booksapp

class Books (var title : String,
             var description : String,
             var urlImage : String ) {
}
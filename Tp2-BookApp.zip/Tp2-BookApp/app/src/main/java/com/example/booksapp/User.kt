package com.example.booksapp

class User (
    var username : String,
    var password : String,
)